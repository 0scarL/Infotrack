package com.example.infotrack.data.model

data class Geo(
    val lat: String,
    val lng: String
)