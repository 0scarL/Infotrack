package com.example.infotrack.data.utils

object Constantes {


    /**definicion de constantes**/

    const val NO_RESULTADO =
        "No hay resultados para esta busqueda, intente nuevamente."

    var PERMISO_CAMARA = false

}


