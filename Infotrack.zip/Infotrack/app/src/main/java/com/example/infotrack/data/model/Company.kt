package com.example.infotrack.data.model

data class Company(
    val bs: String,
    val catchPhrase: String,
    val name: String
)